
package com.example.TextDetectionApplication;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.AmazonRekognitionException;
import com.amazonaws.services.rekognition.model.DetectTextRequest;
import com.amazonaws.services.rekognition.model.DetectTextResult;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.TextDetection;
import com.amazonaws.services.rekognition.model.S3Object;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.DeleteMessageRequest;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TextDetectionApplication {

    public static void main(String[] args) {
        String queueUrl = "https://sqs.us-east-1.amazonaws.com/210071813569/MyQueueCar.fifo";
        String bucketName = "njit-cs-643";

        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();
        AmazonRekognition rekognitionClient = AmazonRekognitionClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();
        AmazonSQS sqs = AmazonSQSClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();

        boolean continueListening = true;
        HashMap<String, String> imageTextMap = new HashMap<>();

        while (continueListening) {
            ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest()
                    .withQueueUrl(queueUrl)
                    .withMaxNumberOfMessages(10);

            List<Message> messages = sqs.receiveMessage(receiveMessageRequest).getMessages();
            System.out.println("Messages received: " + messages.size());

            for (Message message : messages) {
                String photo = message.getBody();

                System.out.println("Received message: " + photo);

                if ("-1".equals(photo)) {
                    continueListening = false;
                } else {
                    DetectTextRequest request = new DetectTextRequest()
                            .withImage(new Image()
                                    .withS3Object(new S3Object()
                                            .withName(photo)
                                            .withBucket(bucketName)));
                    try {
                        DetectTextResult result = rekognitionClient.detectText(request);
                        List<TextDetection> textDetections = result.getTextDetections();

                        System.out.println("Detected text for " + photo);
                        String fullText = "";

                        for (TextDetection text : textDetections) {
                            System.out.println("Detected: " + text.getDetectedText());
                            System.out.println("Confidence: " + text.getConfidence().toString());
                            System.out.println("Id : " + text.getId());
                            System.out.println("Parent Id: " + text.getParentId());
                            System.out.println("Type: " + text.getType());
                            System.out.println();
                            fullText += text.getDetectedText();
                        }

                        if (!fullText.isEmpty()) {
                            imageTextMap.put(photo, fullText);
                        }
                    } catch (AmazonRekognitionException e) {
                        e.printStackTrace();
                    }
                }

                // After processing the message, delete it from the queue
                String messageReceiptHandle = message.getReceiptHandle();
                sqs.deleteMessage(new DeleteMessageRequest(queueUrl, messageReceiptHandle));
            }
        }

        System.out.println(imageTextMap);
        String fileName = "output.txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Map.Entry<String, String> entry : imageTextMap.entrySet()) {
                writer.write(entry.getKey() + " - " + entry.getValue());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }
    }

}
