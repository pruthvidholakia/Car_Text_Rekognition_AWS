package com.example.CarDetection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarDetectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
