package com.example.CarDetection;

import java.io.IOException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.AmazonRekognitionException;
import com.amazonaws.services.rekognition.model.DetectLabelsRequest;
import com.amazonaws.services.rekognition.model.DetectLabelsResult;
import com.amazonaws.services.rekognition.model.Image;
import com.amazonaws.services.rekognition.model.Label;
import com.amazonaws.services.rekognition.model.S3Object;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ListObjectsV2Request;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.CreateQueueRequest;
import com.amazon.sqs.javamessaging.AmazonSQSMessagingClientWrapper;
import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnection;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.services.sqs.model.SendMessageRequest;

@SpringBootApplication
public class CarDetectionApplication {

    public static void main(String[] args) {
        // Initialize AWS clients for S3, Rekognition, and SQS
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)  // Your bucket region
                .build();
        AmazonRekognition rekognitionClient = AmazonRekognitionClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();
        AmazonSQS sqs = AmazonSQSClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();

        // Your S3 bucket name
        String bucketName = "njit-cs-643";

        List<String> images = new ArrayList<>();
        ObjectListing objectListing = s3Client.listObjects(bucketName);
        for (S3ObjectSummary os : objectListing.getObjectSummaries()) {
            System.out.println(os.getKey());
            images.add(os.getKey());
        }

        for (String photo : images) {
            DetectLabelsRequest request = new DetectLabelsRequest()
                    .withImage(new Image()
                            .withS3Object(new S3Object()
                                    .withName(photo).withBucket(bucketName)))
                    .withMinConfidence(90F);

            try {
                DetectLabelsResult result = rekognitionClient.detectLabels(request);
                List<Label> labels = result.getLabels();

                System.out.println("Detected labels for " + photo);
                for (Label label : labels) {
                    System.out.println(label.getName() + ": " + label.getConfidence().toString());
                    if ("Car".equals(label.getName())) {
                        SendMessageRequest send_msg_request = new SendMessageRequest()
                                .withQueueUrl("https://sqs.us-east-1.amazonaws.com/210071813569/MyQueueCar.fifo")  // Replace with your SQS queue URL
                                .withMessageBody(photo)
                                .withMessageGroupId("messageGroup1")
                                .withMessageDeduplicationId(UUID.randomUUID().toString());
                        sqs.sendMessage(send_msg_request);
                        System.out.println("Sent " + photo + " to SQS Queue");
                        break;
                    }
                }
            } catch (AmazonRekognitionException e) {
                e.printStackTrace();
            }
        }

        // Send a signal to indicate the end of processing
        SendMessageRequest send_msg_request = new SendMessageRequest()
                .withQueueUrl("https://sqs.us-east-1.amazonaws.com/210071813569/MyQueueCar.fifo")  // Replace with your SQS queue URL
                .withMessageBody("-1")
                .withMessageGroupId("messageGroup1")
                .withMessageDeduplicationId(UUID.randomUUID().toString());
        sqs.sendMessage(send_msg_request);
        System.out.println("Sent -1 to SQS Queue");
    }
}
